﻿using System;

namespace Smysl_Zhizni
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vpishite imia dna:");
            String blablabla = Console.ReadLine();
            while (true)
            {
                Console.Write("S dnuhoj "+blablabla+" ! ");
            }            
        }
    }
}
